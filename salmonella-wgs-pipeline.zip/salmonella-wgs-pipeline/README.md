# Salmonella WGS Pipeline

This repository contains a reproducible pipeline to process Salmonella enterica whole-genome sequencing (WGS) data.

**Important:** No raw sequencing data is included. The pipeline is designed to run on public SRA datasets (e.g., SRR1552456, SRR1552457).

## Features
- Align paired-end reads to reference genome using BWA
- Convert and sort BAM files using samtools
- QC BAM files (flagstat)
- Variant calling with bcftools
- Produce filtered VCF files (QUAL>30)

## Folder Structure
- pipeline/ → Main pipeline script
- example_data/ → Dummy FASTQ files for testing
- docs/ → Usage instructions
- .gitignore → Exclude large files

## Usage
1. Download public FASTQ data from NCBI SRA.
2. Place FASTQ files in raw_reads/ folder.
3. Run:
```bash
bash pipeline/salmonella_wgs_pipeline.sh
```
4. Outputs:
- Sorted BAMs → alignment/
- Filtered VCF → vcf/salmonella_variants.filtered.vcf
- QC reports → alignment/*.flagstat.txt, vcf/*.stats.txt
