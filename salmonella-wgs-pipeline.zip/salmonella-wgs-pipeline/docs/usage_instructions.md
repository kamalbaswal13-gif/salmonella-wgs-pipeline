# Usage Instructions

1. Install bwa, samtools, bcftools.
2. Download SRA FASTQ or use dummy files in example_data/.
3. Run pipeline:
```
bash pipeline/salmonella_wgs_pipeline.sh
```
4. Check outputs in alignment/ and vcf/ folders.
