#!/bin/bash
# Salmonella WGS Pipeline Script (dummy-ready)
THREADS=4
RAW_DIR=example_data
PROJECT_DIR=$(pwd)
REF_DIR=$PROJECT_DIR/reference
ALIGN_DIR=$PROJECT_DIR/alignment
VCF_DIR=$PROJECT_DIR/vcf

mkdir -p $REF_DIR $ALIGN_DIR $VCF_DIR

echo "This is a dummy pipeline script. Replace with actual paths and data for real runs."
